# No Python models needed - pure QWeb report module
