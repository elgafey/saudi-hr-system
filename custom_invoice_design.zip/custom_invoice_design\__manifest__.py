{
    'name': 'Custom Invoice Design',
    'version': '19.0.1.0.0',
    'summary': 'Custom professional ZATCA-compliant invoice PDF report (bilingual Arabic/English)',
    'description': """
Custom Invoice Design Module
============================

Small Custom QWeb Report Module for Customer Invoices (account.move)
- Professional bilingual design (Arabic/English) matching ZATCA requirements
- Dynamic QR code (supports standard Saudi/GCC localization fields)
- Binds to Customer Invoices Print menu (account.move)
- Credit Note support (out_refund)
- Standalone: does NOT modify standard Odoo reports
    """,
    'author': 'Custom Development',
    'category': 'Accounting/Accounting',
    'license': 'LGPL-3',
    'depends': ['base', 'account'],
    'data': [
        'report/invoice_report.xml',
        'report/invoice_report_template.xml',
    ],
    'assets': {
        'web.report_assets_common': [
            'custom_invoice_design/report/invoice_report.css',
        ],
    },
    'installable': True,
    'application': False,
    'auto_install': False,
}
